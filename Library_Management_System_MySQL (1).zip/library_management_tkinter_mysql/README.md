# Library Management System — Tkinter + MySQL

## 1. Project overview
A simple desktop Library Management System developed for a final-year student project.

**Technology stack**
- Frontend: Python Tkinter / ttk
- Backend: MySQL
- Database driver: mysql-connector-python
- Architecture: Desktop GUI + relational database

## 2. Features
- Book CRUD: add, view, update, delete
- Member CRUD: add, view, update, delete
- Issue book
- Return book
- Automatic due date calculation
- Automatic fine calculation
- Availability tracking
- Dashboard statistics
- Input validation
- Business-rule validation
- Transaction-safe issue/return updates

## 3. Business rules
1. A member can have at most 3 active books.
2. A loan is normally due after 14 days.
3. Fine is ₹5 per overdue day.
4. A book cannot be issued if available copies are zero.
5. A member cannot issue the same book twice at the same time.
6. A book cannot be deleted while it is issued.
7. A member cannot be deleted while they have an active issue.
8. When returned, available copies increase automatically.
9. Book total copies cannot be reduced below currently issued copies.

## 4. Installation

### Step 1 — Install Python
Python 3.10+ is recommended.

### Step 2 — Install MySQL
Install MySQL Server and MySQL Workbench (optional).

### Step 3 — Create database
Open MySQL Workbench or the MySQL command line and execute:

    database/schema.sql

### Step 4 — Install Python dependency

    pip install -r requirements.txt

### Step 5 — Configure database password
Open `app.py` and change:

    "password": "YOUR_MYSQL_PASSWORD"

Set it to your MySQL root password (or another MySQL user's password).

### Step 6 — Run

    python app.py

## 5. Suggested viva demonstration
1. Add a new book.
2. Add a new member.
3. Issue a book using member ID and book ID.
4. Show available copies decreasing.
5. Try issuing more than 3 books to demonstrate a business rule.
6. Return a book.
7. Show fine calculation by changing a test transaction's due date in MySQL.
8. Update and delete a book/member.
9. Show dashboard statistics.

## 6. Project structure

    library_management_tkinter_mysql/
    ├── app.py
    ├── requirements.txt
    ├── README.md
    ├── database/
    │   └── schema.sql
    └── docs/
        └── Final_Year_Project_Report.docx

## 7. Notes
This project is intentionally kept simple enough for a student to understand and explain during a viva. For production use, credentials should be stored securely in environment variables rather than directly in source code.
